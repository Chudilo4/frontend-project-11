export default {
  plugins: [
    'postcss-preset-env',
  ],
};
