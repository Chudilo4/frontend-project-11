// @ts-check

import init from './init.js';
import './style.css';

init();
